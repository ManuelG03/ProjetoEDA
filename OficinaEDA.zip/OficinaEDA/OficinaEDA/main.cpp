#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <fstream>
#include <string>
#include "constantes.h"

using namespace std;

struct ET {
    int capacidade;
    string mecanico;
    string marca;
};

void criarEstacoes(int num_ETs) {
    string fileName = "marcas.txt";
    ifstream file(fileName);
    string marca;
    
    /*if (file.is_open()) {
        while (getline(file, marca)) {
            num_marcas++;
        }
    }*/

    string* marcas = new string[linhas];

    if (file.is_open()) {
        while (getline(file, marca)) {
            for (int i = 0; i < linhas; i++)
            {
                marcas[i] = marca;
            }
        }
    }

    ET* estacoes = new ET[num_ETs];
    //string* marcas = new string[num_marcas];
        /*for (int i = 0; i < num_marcas; i++)
        {
            marcas[i] = marca;
        }*/

    for (int i = 0; i < linhas; i++)
    {
        cout << "Marca " << i << ": " << marcas[i] << endl;
    }

    /*for (int i = 0; i < num_ETs; i++)
    {
        ET* et = new ET[i];
        cout << "Introduza o mec�nico para a esta��o " << i << ": ";
        cin >> estacoes[i].mecanico;
        estacoes[i].capacidade = rand() % 4 + 2;
        estacoes[i].marca = marcas[i];
    }
    
    

    for (int i = 0; i < num_ETs; i++)
    {
        cout << "Mec�nico esta��o " << i << ": ";
        cout << estacoes[i].mecanico;
        cout << endl << "Capacidade:";
        cout << estacoes[i].capacidade << endl;
        cout << endl << "Marca:";
        cout << estacoes[i].marca << endl;
    }*/
}

int main() {
    locale::global(locale(""));
    srand(time(NULL));

    int num_ETs;
    num_ETs = rand() % 6 + 3;
    criarEstacoes(num_ETs);

    /*for (int i = 0; i < num_ETs; i++)
    {
        cout << "Introduza o nome do mec�nico: ";
        cin >> mecanico;
    }*/

    return 0;
}