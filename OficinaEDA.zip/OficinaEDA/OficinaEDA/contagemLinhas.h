#pragma once

int contarMarcas();
const int num_marcas = contarMarcas();

int contarModelos();
const int num_modelos = contarModelos();