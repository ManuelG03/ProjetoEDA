#pragma once
const int linhas = 46;